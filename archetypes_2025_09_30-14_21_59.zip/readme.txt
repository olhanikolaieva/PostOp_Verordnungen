These are archetypes exported from the Clinical Knowledge Manager.
Export time: Tue Sep 30 14:21:59 CEST 2025